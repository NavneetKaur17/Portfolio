#include <iostream>
// Lab 2 part 1
// Name: Navneet Kaur
// Date: September 28, 2022

using namespace std;

int main()
{
	int numvalue = 0;
	cin >> numvalue;
	cout << "Enter any number to multiply 4:" << numvalue << endl;
	cout << numvalue << " * 4 = " << numvalue * 4 << endl;
	
	return 0;
}